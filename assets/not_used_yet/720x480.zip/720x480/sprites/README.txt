720 X 480 INFO
1) mainChar.png Sprite Dimensions [223x366]px
2) bigGun.png Sprite Dimensions [272x93]px
3) smallGun.png Sprite Dimensions [141x51]px
4) baddie[eye-guy].png Sprite Dimensions [248x235]px
5) baddie[legs].png Sprite Dimensions [287x228]px

