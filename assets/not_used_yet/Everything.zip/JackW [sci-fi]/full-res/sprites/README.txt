FULL RESOLUTION INFO
1) mainChar.png Sprite Dimensions [390x642]px
2) bigGun.png Sprite Dimensions [480x165]px
3) smallGun.png Sprite Dimensions [247x88]px
4) baddie[eye-guy].png Sprite Dimensions [432x413]px
5) baddie[legs].png Sprite Dimensions [504x400]px

