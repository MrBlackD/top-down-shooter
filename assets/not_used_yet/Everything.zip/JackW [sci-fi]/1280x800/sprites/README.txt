1280 X 800 INFO
1) mainChar.png Sprite Dimensions [371x610]px
2) bigGun.png Sprite Dimensions [452x157]px
3) smallGun.png Sprite Dimensions [235x84]px
4) baddie[eye-guy].png Sprite Dimensions [412x392]px
5) baddie[legs].png Sprite Dimensions [480x380]px

