960 X 540 INFO
1) mainChar.png Sprite Dimensions [250x415]px
2) bigGun.png Sprite Dimensions [306x107]px
3) smallGun.png Sprite Dimensions [159x57]px
4) baddie[eye-guy].png Sprite Dimensions [277x265]px
5) baddie[legs].png Sprite Dimensions [323x257]px

